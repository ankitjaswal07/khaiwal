<?php
/** Opt-in, bounded reference chart snapshot importer. Results stay pending until reviewed in the plugin. */
defined('ABSPATH') || exit;

function gbk_reference_parse_chart(string $html,int $year): array|WP_Error {
    if(!class_exists('DOMDocument'))return new WP_Error('dom','The PHP DOM extension is required.');
    $doc=new DOMDocument();
    $previous=libxml_use_internal_errors(true);
    $loaded=$doc->loadHTML('<?xml encoding="utf-8" ?>'.$html,LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING);
    libxml_clear_errors();libxml_use_internal_errors($previous);
    if(!$loaded)return new WP_Error('html','Cannot parse the reference chart.');
    $xpath=new DOMXPath($doc);$records=array();
    $months=array('JAN'=>1,'FEB'=>2,'MAR'=>3,'APR'=>4,'MAY'=>5,'JUN'=>6,'JUL'=>7,'AUG'=>8,'SEP'=>9,'OCT'=>10,'NOV'=>11,'DEC'=>12);
    foreach($xpath->query('//table') as $table){
        $rows=$xpath->query('.//tr',$table);if(!$rows || !$rows->length)continue;
        $columns=array();$header=$xpath->query('./th|./td|./thead/tr[1]/th|./thead/tr[1]/td|./tbody/tr[1]/th|./tbody/tr[1]/td',$table);
        foreach($header as $index=>$cell){$text=strtoupper(trim(preg_replace('/\s+/u',' ',$cell->textContent)));$key=substr($text,0,3);if(isset($months[$key]))$columns[$index]=$months[$key];}
        if(count($columns)<6)continue; // Ignore daily and advertising tables.
        $title=$xpath->query('preceding::h1[1] | preceding::h2[1]',$table);
        $heading=$title && $title->length ? strtoupper(trim($title->item($title->length-1)->textContent)) : ''; 
        if(!preg_match('/\b20\d{2}\b/',$heading,$matches) || (int)$matches[0]!==$year)continue;
        foreach($rows as $row){
            $cells=$xpath->query('./th|./td',$row);if(!$cells||$cells->length<7)continue;
            $day=trim($cells->item(0)->textContent);
            if(!preg_match('/^\d{1,2}$/D',$day)|| (int)$day<1||(int)$day>31)continue;
            foreach($columns as $index=>$month){
                if($index >= $cells->length || !checkdate($month,(int)$day,$year))continue;
                $value=trim($cells->item($index)->textContent);
                if(!preg_match('/^\d{2}$/D',$value))continue; // Dashes and malformed cells are not results.
                $records[sprintf('%04d-%02d-%02d',$year,$month,(int)$day)]=$value;
            }
        }
        if($records)break;
    }
    return $records ?: new WP_Error('layout','No unambiguous 12-month chart was found. The reference layout may have changed; use an exported CSV instead.');
}

function gbk_reference_import(string $slug,int $year): array|WP_Error {
    if(!class_exists('SRM_Results')||!class_exists('SRM_Access')||!SRM_Access::current_user_has_full_access())return new WP_Error('access','A full Results Manager administrator account is required.');
    if($year<2024||$year>(int)wp_date('Y'))return new WP_Error('year','Select a supported year.');
    $game=null;
    foreach(SRM_Games::get_all_games() as $candidate)if($candidate->slug===$slug){$game=$candidate;break;}
    if(!$game)return new WP_Error('game','Select a configured game.');
    // Fixed allowlisted host and a slug from the plugin database, never an arbitrary request URL.
    $reference_slugs=array('dishavar'=>'disawer','ghaziabad'=>'gaziabad','hr-matka'=>'hr-satta');
    $reference_slug=$reference_slugs[$slug]??$slug;
    $source='https://a1-satta.com/'.rawurlencode($reference_slug).($year===(int)wp_date('Y')?'':'?year='.$year);
    $response=wp_safe_remote_get($source,array('timeout'=>15,'redirection'=>2,'limit_response_size'=>1500000,'headers'=>array('Accept'=>'text/html')));
    if(is_wp_error($response))return $response;
    if(200!==wp_remote_retrieve_response_code($response))return new WP_Error('http','The reference page did not return HTTP 200.');
    $records=gbk_reference_parse_chart(wp_remote_retrieve_body($response),$year);
    if(is_wp_error($records))return $records;
    $summary=array('found'=>count($records),'imported'=>0,'existing'=>0,'invalid'=>0);
    foreach($records as $date=>$value){
        if($date>wp_date('Y-m-d'))continue;
        $result=SRM_Results::save_result((int)$game->id,$date,array('result_value'=>$value,'result_status'=>'pending','original_game_name'=>$game->event_name,'source_url'=>$source,'verification_status'=>'unverified','verification_notes'=>'Imported from a public reference chart on '.wp_date('Y-m-d').'. Verify the source game, date and number before publication.'),true);
        if(is_wp_error($result))$summary['duplicate'===$result->get_error_code()?'existing':'invalid']++;
        else $summary['imported']++;
    }
    return $summary;
}
add_action('admin_post_gbk_reference_import',function(){
    if(!current_user_can('manage_options'))wp_die('Permission denied.','',array('response'=>403));
    check_admin_referer('gbk_reference_import');
    $result=gbk_reference_import(sanitize_title(wp_unslash($_POST['game']??'')),absint($_POST['year']??0));
    $message=is_wp_error($result)?$result->get_error_message():sprintf('Found %d; staged %d pending review; existing %d; invalid %d. No records were automatically published.',$result['found'],$result['imported'],$result['existing'],$result['invalid']);
    set_transient('gbk_reference_'.get_current_user_id(),$message,120);
    wp_safe_redirect(admin_url('themes.php?page=gbk-site-setup'));exit;
});
